class Constants:
	PROJECT_NAME='shallow-backup'
	VERSION='1.3'
	AUTHOR_GITHUB='alichtman'
	AUTHOR_FULL_NAME='Aaron Lichtman'
	DESCRIPTION="Easily create lightweight documentation of installed packages, dotfiles, and more."
	URL='https://github.com/alichtman/shallow-backup',
	AUTHOR_EMAIL='aaronlichtman@gmail.com',
